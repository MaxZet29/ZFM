
#include "Functions.h"


int create() {
    endwin();
    printf("Jmeno noveho souboru? : ");
    scanf("%s", novysoubor);
    system("cls");
    doupdate();
    initscr();

    char command[50], folder[50], jmenosouboru[50];

    strcpy(command, "call>");
    strcpy(folder, path);
    strcpy(jmenosouboru, novysoubor);

    strcat(command, folder);
    strcat(command, jmenosouboru);

    system(command);
    return 0;
}

int rename() {
    endwin();
    printf("Nove jmeno? : ");
    scanf("%s", novejmeno);
    system("cls");
    doupdate();
    initscr();
    for (int i = 0; i < 70; i++)
    {
        if (selected[i] == 1)
        {
            list[i][70] = list[i + 1][70];

            char command[50], folder[50], selection[50], mezera[10], novejm[50];

            strcpy(command, "ren ");
            strcpy(folder, path);
            strcpy(selection, list[i]);
            strcpy(mezera, " ");
            strcpy(novejm, novejmeno);

            strcat(command, folder);
            strcat(command, selection);
            strcat(command, mezera);
            strcat(command, novejm);

            system(command);
        }
    }
    return 0;
}
int mov() {
    endwin();
    printf("Kam to bude? : ");
    scanf("%s", kamtobude);
    system("cls");
    doupdate();
    initscr();
    for (int i = 0; i < 70; i++)
    {
        if (selected[i] == 1)
        {
            list[i][70];

            char command[50], folder[50], selection[50], mezera[10], kam[50];

            strcpy(command, "move ");
            strcpy(folder, path);
            strcpy(selection, list[i]);
            strcpy(mezera, " ");
            strcpy(kam, kamtobude);

            strcat(command, folder);
            strcat(command, selection);
            strcat(command, mezera);
            strcat(command, kam);

            system(command);
        }
        if (selected[i] == 1)
        {
            list[i][70];

            char command[50], folder[50], selection[50], mezera[10], kam[50];

            strcpy(command, "move ");
            strcpy(folder, path);
            strcpy(selection, list[i]);
            strcpy(mezera, " ");
            strcpy(kam, kamtobude);

            strcat(command, folder);
            strcat(command, selection);
            strcat(command, mezera);
            strcat(command, kam);

            system(command);
        }
    }
    return 0;
}
int copy() {
    endwin();
    printf("Kam to bude? : ");
    scanf("%s", kamtobude);
    system("cls");
    doupdate();
    initscr();
    for (int i = 0; i < 70; i++)
    {
        if (selected[i] == 1)
        {
            list[i][70];

            char command[50], folder[50], selection[50], mezera[10], kam[50];

            strcpy(command, "copy ");
            strcpy(folder, path);
            strcpy(selection, list[i]);
            strcpy(mezera, " ");
            strcpy(kam, kamtobude);

            strcat(command, folder);
            strcat(command, selection);
            strcat(command, mezera);
            strcat(command, kam);

            system(command);
        }
        if (selected[i] == 1)
        {
            list[i][70];

            char command[50], folder[50], selection[50], mezera[10], kam[50];

            strcpy(command, "copy ");
            strcpy(folder, path);
            strcpy(selection, list[i]);
            strcpy(mezera, " ");
            strcpy(kam, kamtobude);

            strcat(command, folder);
            strcat(command, selection);
            strcat(command, mezera);
            strcat(command, kam);

            system(command);
        }
    }
    return 0;
}
int del() {
    for (int i = 0; i < 70; i++)
    {
        if (selected[i] == 1)
        {
            list[i][70];

            char command[50], folder[50], selection[50];

            strcpy(command, "del ");
            strcpy(folder, cesta);
            strcpy(selection, list[i]);

            strcat(command, folder);
            strcat(command, selection);

            system(command);
        }
        if (selected[i] == 1)
        {
            list[i][70];

            char command[50], folder[50], selection[50];

            strcpy(command, "del ");
            strcpy(folder, cesta);
            strcpy(selection, list[i]);

            strcat(command, folder);
            strcat(command, selection);

            system(command);
        }
    }
    return 0;
}


int create2() {
    endwin();
    printf("Jmeno noveho souboru? : ");
    scanf("%s", novysoubor);
    system("cls");
    doupdate();
    initscr();

    char command[50], folder[50], jmenosouboru[50];

    strcpy(command, "call>");
    strcpy(folder, path2);
    strcpy(jmenosouboru, novysoubor);

    strcat(command, folder);
    strcat(command, jmenosouboru);

    system(command);
}
int rename2() {
    endwin();
    printf("Nove jmeno? : ");
    scanf("%s", novejmeno);
    system("cls");
    doupdate();
    initscr();
    for (int i2 = 0; i2 < 70; i2++)
    {
        if (selected2[i2] == 1)
        {
            list2[i2][70] = list2[i2 + 1][70];

            char command[50], folder[50], selection[50], mezera[10], novejm[50];

            strcpy(command, "ren ");
            strcpy(folder, path2);
            strcpy(selection, list2[i2]);
            strcpy(mezera, " ");
            strcpy(novejm, novejmeno);

            strcat(command, folder);
            strcat(command, selection);
            strcat(command, mezera);
            strcat(command, novejm);

            system(command);
        }
    }
}
int mov2(){
    endwin();
    printf("Kam to bude? : ");
    scanf("%s", kamtobude);
    system("cls");
    doupdate();
    initscr();
    for (int i2 = 0; i2 < 70; i2++)
    {
        if (selected2[i2] == 1)
        {
            list2[i2][70];

            char command[50], folder[50], selection[50], mezera[10], kam[50];

            strcpy(command, "move ");
            strcpy(folder, path2);
            strcpy(selection, list2[i2]);
            strcpy(mezera, " ");
            strcpy(kam, kamtobude);

            strcat(command, folder);
            strcat(command, selection);
            strcat(command, mezera);
            strcat(command, kam);

            system(command);
        }
        if (selected2[i2] == 1)
        {
            list2[i2][70];

            char command[50], folder[50], selection[50], mezera[10], kam[50];

            strcpy(command, "move ");
            strcpy(folder, path2);
            strcpy(selection, list2[i2]);
            strcpy(mezera, " ");
            strcpy(kam, kamtobude);

            strcat(command, folder);
            strcat(command, selection);
            strcat(command, mezera);
            strcat(command, kam);

            system(command);
        }
    }
}
int copy2(){
    endwin();
    printf("Kam to bude? : ");
    scanf("%s", kamtobude);
    system("cls");
    doupdate();
    initscr();
    for (int i2 = 0; i2 < 70; i2++)
    {
        if (selected2[i2] == 1)
        {
            list2[i2][70];

            char command[50], folder[50], selection[50], mezera[10], kam[50];

            strcpy(command, "copy ");
            strcpy(folder, path2);
            strcpy(selection, list2[i2]);
            strcpy(mezera, " ");
            strcpy(kam, kamtobude);

            strcat(command, folder);
            strcat(command, selection);
            strcat(command, mezera);
            strcat(command, kam);

            system(command);
        }
        if (selected2[i2] == 1)
        {
            list2[i2][70];

            char command[50], folder[50], selection[50], mezera[10], kam[50];

            strcpy(command, "copy ");
            strcpy(folder, path2);
            strcpy(selection, list2[i2]);
            strcpy(mezera, " ");
            strcpy(kam, kamtobude);

            strcat(command, folder);
            strcat(command, selection);
            strcat(command, mezera);
            strcat(command, kam);

            system(command);
        }
    }
}
int del2(){
    for (int i2 = 0; i2 < 70; i2++)
    {
        if (selected[i2] == 1)
        {
            list2[i2][70];

            char command[50], folder[50], selection[50];

            strcpy(command, "del ");
            strcpy(folder, cesta2);
            strcpy(selection, list2[i2]);

            strcat(command, folder);
            strcat(command, selection);

            system(command);
        }
        if (selected2[i2] == 1)
        {
            list2[i2][70];

            char command[50], folder[50], selection[50];

            strcpy(command, "del ");
            strcpy(folder, cesta2);
            strcpy(selection, list2[i2]);

            strcat(command, folder);
            strcat(command, selection);

            system(command);
        }
    }
}